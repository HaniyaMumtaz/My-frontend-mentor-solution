# Frontend Mentor - Social links profile solution

This is a solution to the [Social links profile challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/social-links-profile-UG32l9m6dQ). Frontend Mentor challenges help you improve your coding skills by building realistic projects. 


# Frontend Mentor - Social Links Profile Solution

This is my solution to the **[Social Links Profile](https://www.frontendmentor.io/challenges/social-links-profile-UG32l9m6d)** challenge on [Frontend Mentor](https://www.frontendmentor.io/). It’s a beginner-friendly challenge to create a responsive card using only **HTML** and **CSS**.

## 📸 Screenshot

![alt text](hovershot.png)
![alt text](<My solution.png>)


## 🛠️ Built With

- HTML5
- CSS3
- Flexbox
- Media Queries
- Mobile-first workflow
- Google Fonts (Inter)

---

## 💡 What I Learned

While building this project, I learned:
- How to use Flexbox to center content both vertically and horizontally.
- How to build a responsive layout using media queries.
- How to style buttons with hover effects and rounded corners.
- How to use good folder structure and organize CSS cleanly.

---

## 🚀 My Process

1. Set up the HTML structure based on the given design.
2. Styled the card using CSS, following a mobile-first approach.
3. Used Flexbox and media queries for responsiveness.
4. Added a Google font (`Inter`) for improved typography.
5. Uploaded to GitHub and deployed using Netlify.

---

## 👩‍💻 Author

- Frontend Mentor – [@Haniya Mumtaz](https://www.frontendmentor.io/profile/yourusername)
- GitHub – [@yourgithub](https://github.com/yourgithub)



## 🙌 Acknowledgments

Thanks to [Frontend Mentor](https://www.frontendmentor.io/) for providing this great challenge! 🎉
